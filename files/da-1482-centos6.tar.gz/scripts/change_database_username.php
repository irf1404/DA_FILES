<?php
$user = getenv('DBUSER');
$pass = getenv('DBPASS');
$username = getenv('USERNAME');
$newusername = getenv('NEWUSERNAME');
$host = 'localhost';
$verbose = getenv('VERBOSE');
$verbose = ($verbose == 1) ? 1 : 0;

if ($username == "" || $username == "root" || $username == "mysql")
{
	die('Bad username. aborting mysql database swap');
}

if ($newusername == "" || $newusername == "root" || $newusername == "mysql")
{
        die('Bad new username. aborting mysql database swap');
}

$link = mysql_connect('localhost',$user,$pass);
if (!$link)
{
	die('Could not connect to mysql: '.mysql_error($link));
}

mysql_select_db('mysql', $link);

replace_users($link);
replace_dbs($link);

mysql_query("FLUSH_PRIVILEGES");

mysql_close($link);

function replace_users($link)
{
	global $username;
	global $newusername;
	//in this function, we need to replace
	// username to newusername
	// username_user to newusername_user
	
	mysql_query("UPDATE mysql.user SET user='$newusername' WHERE user='$username'", $link);
	mysql_query("UPDATE mysql.db SET user='$newusername' WHERE user='$username'", $link);
	$query = "SELECT user FROM mysql.user WHERE user LIKE '$username\\_%'";
	$result = mysql_query($query, $link);
	while ($row = mysql_fetch_array($result))
	{
		$user = $row['user'];
		//$new_user = ereg_replace($username."_", $newusername."_", $user);
		$new_user = preg_replace('/'.$username.'_/', $newusername."_", $user);

		vecho("swapping '$user' with '$new_user'");
		
		$query = "UPDATE mysql.user SET user='$new_user' WHERE user='$user'";
		mysql_query($query, $link) or vecho("Error updating $user to $newuser in mysql.user: ".mysql_error($link)."\n");
	
		$query = "UPDATE mysql.db SET user='$new_user' WHERE user='$user'";
		mysql_query($query, $link) or vecho("Error updating $user to $newuser in mysql.db: ".mysql_error($link)."\n");
	}
}
function replace_dbs($link)
{
	global $username;
	global $newusername;
	global $host;

	//in this function, we need to replace
	// username_db and username\_db to newusername\_db (many)

	$dblist =  mysql_list_dbs($link);
	while ($dbrow = mysql_fetch_object($dblist))
	{
		
		$dbname = $dbrow->Database;

		$user_prefix = $username."_";
		$prefix_len = strlen($user_prefix);
		if (strncmp($dbname, $user_prefix, $prefix_len))
		{	//doesn't belong to this user, so ignore it.
			//vecho("              Skipping $dbname.");
			continue;
		}

		vecho("swapping database $dbname for user $newusername...");

		$esc_dbname = preg_replace('/_/',"\\_", $dbname);

		//$new_dbname = ereg_replace($username."_", $newusername."_", $dbname);
		$new_dbname = preg_replace('/'.$username.'\\_/', $newusername.'_', $dbname);

		$esc_new_dbname = preg_replace('/_/',"\\_", $new_dbname);

		vecho("dbname=$dbname\nesc_dbname=$esc_dbname\nnew_dbname=$new_dbname\nesc_new_dbname=$esc_new_dbname");
		$query = "UPDATE mysql.db SET db='$esc_new_dbname' WHERE db='$dbname' OR db='$esc_dbname'";
		
		mysql_query($query, $link); // or echo("Query error renaming db: ".mysql_error());
		
		//now, rename that actual directory.
		if ($host != 'localhost')
		{
			echo "Your host is not 'localhost', thus you must manually rename the database directory on the remote mysql server\n";
			continue;
		}

		$data = get_data_dir();
		if (!file_exists($data))
		{
			echo "Cannot find data path: $data.  You'll need to manually rename the database directory\n";
			continue;
		}		

		$db_data = $data.'/'.$dbname;
		$new_db_data = $data.'/'.$new_dbname;

		vecho("Renaming $db_data to be $new_db_data");
		if (!rename($db_data, $new_db_data))
		{
			echo "Error renaming $db_data to $new_db_data";
		}
	}

	echo "";
}

function vecho($str)
{
	global $verbose;
	
	if ($verbose)
	echo $str."\n";
}

function get_data_dir()
{
	if (file_exists("/etc/redhat-release"))
		return "/var/lib/mysql";

	return "/usr/local/mysql/data";
}

?>
