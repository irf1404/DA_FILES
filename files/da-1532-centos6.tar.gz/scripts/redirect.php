<?php
header("Location: http://".$_SERVER['HTTP_HOST'].":2222");
?>
